package com.example.esercizio_develhope_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsercizioDevelhope2Application {

	public static void main(String[] args) {
		SpringApplication.run(EsercizioDevelhope2Application.class, args);
	}

}
