package com.example.esercizio_develhope_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsercizioDevelhope2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
